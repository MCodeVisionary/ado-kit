# Security overview

This kit is a **read-only sizing aid**. Review everything below before installing. The whole
code base is two ~60-line decorator files, one manifest and one stdlib-only Python script.

## What the decorator does

For every agent job it runs two small steps (one at job start, one at job end):

1. Reads the machine's cumulative network byte counters (`/proc/net/dev`, `netstat -ib`,
   or `Get-NetAdapterStatistics`) and counts running `Agent.Worker` processes.
2. Writes one JSON record (about 600 bytes) and attaches it to the build with type `netusage`.
   The same record is echoed to the job log on a line starting with `NETUSAGE `.

### Fields recorded (complete list)

Build ID, project name, pipeline name, job name, job ID, agent name, agent OS and
architecture, self-hosted flag, start and end time, duration, bytes received, bytes sent,
and the number of agent workers on the host.

### Not recorded

Environment variables, secrets, tokens, repository names or contents, branch names,
commit info, URLs, destination hosts or IPs, packet contents, user names, command lines.

## Controls

| Risk | Control |
|---|---|
| Breaking builds | Steps use `continueOnError: true`, a 2-minute timeout, and always `exit 0`. |
| Code injection through pipeline or project names | Values reach scripts only through `env:` and are never macro-expanded into script text. Strings are stripped of control characters, length-capped and JSON-escaped (tested with hostile input, see `tests/`). |
| Log command injection (`##vso[...]`) | Our log line starts with `NETUSAGE `, and the only logging command emitted is the attachment command with a validated GUID name. |
| Path traversal | The job ID must match `[0-9a-fA-F-]+` or the step exits; files live only in the agent's own temp directory (mode 0600). |
| Data exfiltration | The decorator makes **no network calls** and contains no URLs. |
| Excess permissions | The extension manifest requests **no scopes**. The decorator never reads `System.AccessToken`. |
| Hosting | `public: false`, no external `baseUri`, no hosted content. Installable from a private `.vsix`, including air-gapped Azure DevOps Server. |
| Kill switch | Set variable `NETUSAGE_DISABLE=true` (org, project or pipeline level) to skip the steps. Uninstalling the extension removes them everywhere. |
| Scope creep | Add the pilot-project condition described in the decorator header to limit the blast radius. |

## Collector script

- Standard library only, so no third-party packages to vet.
- **GET requests only.** It never modifies anything in Azure DevOps.
- PAT comes from the `ADO_PAT` environment variable, never a command-line argument, so it does not appear in shell history or process lists. It is never printed or written to disk.
- Create the PAT with **Project and Team: Read** and **Build: Read** only, expiry of 7 days or less. Revoke it afterwards.
- HTTPS enforced (plain HTTP only for loopback testing). Redirects are refused so the
  `Authorization` header can never be forwarded elsewhere. Any link in an API response pointing at a different host is refused.
- Response sizes and request time are capped; downloaded records are re-validated field by
  field and unknown fields dropped.
- Daily data files and output CSVs are mode 0600 (data directory 0700). Daily files hold real project and pipeline names: keep them on your side.
- Output CSVs are mode 0600. Cells that start with `=`, `+`, `-` or `@` are prefixed so
  pipeline-controlled text cannot become a spreadsheet formula.
- `--anonymize` replaces project and pipeline names with aliases and omits job and agent
  names. The alias map stays on your side.

## Residual risks to be aware of

- A decorator applies to **every** pipeline in the organization it is installed in. That is
  the intended behavior but is why a pilot project and a review are recommended.
- Anyone who can edit the extension can run code in every pipeline. Install it only from a
  `.vsix` your team has reviewed, built and checksummed, and limit who may manage extensions.
- Pipeline authors can already see the `NETUSAGE` line in logs and the attachment on their
  builds. It contains only the fields listed above.
- Counters are machine-wide. On shared self-hosted hosts, concurrent jobs inflate each
  other's numbers; the `maxWorkersOnHost` field lets you filter those samples out.

## Verifying what you received

```bash
shasum -a 256 -c SHA256SUMS      # after unpacking the kit
python3 -I -m unittest discover -s tests -v
```

Report security questions to your JFrog solutions engineer.
