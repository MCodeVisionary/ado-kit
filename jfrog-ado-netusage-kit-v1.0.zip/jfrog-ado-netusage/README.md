# Pipeline Network Usage Sizer

A small, read-only Azure DevOps extension that measures how many bytes each pipeline job
receives and sends, so you can size storage and data transfer before moving to JFrog Cloud.
It works with **Azure DevOps Services** and **Azure DevOps Server**, on **Microsoft-hosted and
self-hosted agents** (Linux, macOS, Windows), and needs **no changes to your pipeline YAML**.

Follow `docs/Azure-DevOps-Usage-Sizing-Guide.docx` (step-by-step guide). This README is the reference, and read `SECURITY.md` for exactly what is collected and the controls in place.

## How it works

```
Every job:  [pre-job step: snapshot NIC counters] -> your steps -> [post-job step: delta -> JSON attachment]
Daily:      collector saves each day's records locally (resumable) -> report builds daily-summary.csv (share this) + pipeline-totals.csv + jobs.csv
```

| Counter | Meaning for JFrog sizing |
|---|---|
| `rxBytes` (received by agent) | Downloads: dependencies, base images, artifact download (in YAML pipelines the source checkout happens before the first step, so it is not counted). Approximates **JFrog egress / data transfer** if that traffic were served by JFrog. |
| `txBytes` (sent by agent) | Uploads: published packages, images, artifacts. Approximates **JFrog ingress and storage growth**. |

Storage estimate: monthly deliverable `txBytes` x retention window, adjusted for deduplication.

## Contents

| Path | Purpose |
|---|---|
| `vss-extension.json` | Extension manifest, no scopes, private |
| `decorators/netusage-pre.yml`, `netusage-post.yml` | The injected steps (Bash for Linux/macOS, PowerShell for Windows) |
| `collector/collect_netusage.py` | Reads results, writes CSVs (Python 3.8+, stdlib only) |
| `tests/` | Unit and integration tests |
| `scripts/package.sh` | Builds the `.vsix` and checksum |

## 1. Install

1. Review the code. Run the tests (`python3 -I -m unittest discover -s tests -v`).
2. Create or pick a Marketplace publisher (Azure DevOps Services) and set its ID in
   `vss-extension.json`. Azure DevOps Server does not validate the publisher.
3. Build: `scripts/package.sh` (needs `tfx-cli`; install it from your internal npm registry).
4. Install the private extension:
   - **Services:** publish privately and share with your organization
     (`tfx extension publish ... --share-with <org>`), then install it from
     Organization settings > Extensions > Shared.
   - **Server:** upload the `.vsix` in the local gallery (`https://<server>/tfs/_gallery/manage`, needs Team Foundation
     Administrators), then install it into the collection (needs Project Collection Administrator).
5. **Pilot first.** Add this to the `condition:` of all four steps in the two decorator files
   to restrict to one project, then rebuild and reinstall:
   `, eq(variables['System.TeamProject'], 'YourPilotProject')`
6. Run any pipeline. Each job log should show `[NetUsage] snapshot start`, `[NetUsage] record usage`
   and a `NETUSAGE {...}` line. The build has an attachment of type `netusage`.

Requires: Azure DevOps Services, or Azure DevOps Server 2022 or later (the manifest targets Server 19.0+;
older servers are not documented by Microsoft for decorators). Covers YAML and classic **build** pipelines;
classic **release** pipelines are not measured. A
Microsoft-hosted or self-hosted agent that supports `Bash@3` / `PowerShell@2`. On Windows,
the `NetAdapter` module (present on Windows 10 / Server 2016 and later).

## 2. Collect

Results live on the builds, so they disappear when Azure DevOps purges the builds under
your retention policy. For large estates, collect **daily** so nothing is lost and no single
run hits API rate limits.

Create a PAT with **Project and Team: Read** and **Build: Read**, expiring as soon as
practical, and keep it in your scheduler's secret store.

### Daily snapshot (recommended)

```bash
export ADO_PAT='<PAT>'
python3 collector/collect_netusage.py --daily \
  --url https://dev.azure.com/YOUR_ORG \
  --data-dir netusage-data --time-budget-minutes 240
```

- Saves finished builds for the previous UTC day to `netusage-data/YYYY-MM-DD.jsonl`
  (about 600 bytes per job) and writes `YYYY-MM-DD.complete` when the day is done.
- **Resumable:** progress is flushed to disk after every 100 builds. If it stops (rate limit,
  network, time budget), rerun it. Already-saved builds are not fetched again. Exit code `3`
  means "time budget reached, rerun to continue", `0` means done.
- **Self-healing:** each run also fills any day in the last `--backfill-days` (default 3)
  that is missing a `.complete` marker, so a missed night is caught up automatically.
- Schedule it once a day shortly after 00:00 UTC (cron, Windows Task Scheduler, or a
  scheduled job on an internal host). If a run exceeds the budget, schedule a second run a few hours later.
- Start the schedule before your build retention window can purge anything; raise
  `--backfill-days` for the first run to pull recent history (only builds that ran after install have data).

Build the CSVs at any time from the saved files (no PAT, no API calls):

```bash
python3 collector/collect_netusage.py --report \
  --data-dir netusage-data --days 30 --out netusage-out --anonymize
```

### One-shot (small estates only)

```bash
python3 collector/collect_netusage.py --url https://dev.azure.com/YOUR_ORG --days 30 --out netusage-out
```

Capped by `--max-builds` (default 20,000). Use `--daily` instead for hundreds of thousands of builds.

### Options and outputs

- **Access:** the PAT user must be able to read every project. Projects it cannot read (HTTP 403/404) are skipped with a warning and listed as `skipped_no_access` in that day's `.complete` file, so check it. Use a service account in a collection-level Readers group for full coverage.
- **Scale (900 projects):** each daily run makes at least one build-list call per project plus about two calls per build. Throttling (HTTP 429) is retried honoring `Retry-After`; use `--time-budget-minutes` and rerun if needed.
- Azure DevOps Server 2022: `--url https://server/tfs/YourCollection --api-version 7.0`.
- `--project NAME` limits the scan (repeatable). `--since 2026-11-01` sets an explicit report start.
- Revoke the PAT when the engagement ends.
- Output files in `--out` (all sizes are **bytes**, not bits; `*_gb` columns use 1 GB = 1,000,000,000 bytes):

  | File | Rows | Share? |
  |---|---|---|
  | **`daily-summary.csv`** | Per UTC day: one `ALL PIPELINES` row with that day's totals, then one row per pipeline | **Yes, send this one** |
  | `pipeline-totals.csv` | One row per pipeline for the whole period, plus a 30-day projection | Optional |
  | `jobs.csv` | One row per job (`rxBytes`, `txBytes` in bytes) | No, internal detail |

  Columns in `daily-summary.csv`: `date` (UTC, when the job finished), `project`, `pipeline`, `builds`, `jobs`,
  `received_bytes` / `received_gb` (downloaded by agents), `sent_bytes` / `sent_gb` (uploaded by agents),
  `job_hours`, `noisy_jobs`, `jobs_missing_data`.
- `--anonymize` aliases names in the CSVs and writes `anonymization-map.LOCAL-ONLY.json`; keep that file private.
  The raw daily files in `--data-dir` are **not** anonymized, so keep that directory on your side.

Review the CSVs, then send **`daily-summary.csv`** to your JFrog contact.

## 3. Interpreting the results

- **Microsoft-hosted agents:** one job per VM, so figures are clean. They include some background OS
  traffic and traffic to Azure DevOps itself (log upload, artifact publish; checkout too in classic build pipelines).
- **Self-hosted agents:** counters are machine-wide. Jobs with `maxWorkersOnHost > 1` overlap other jobs
  and are inflated; the reports flag them in `noisy_jobs`. Prefer one-agent-per-VM pools for the pilot.
- **Only totals:** you will not see which registry the bytes came from. For a per-destination breakdown,
  use proxy or firewall logs on self-hosted agents.
- **Projection:** per-30-day figures scale the observed window; run through at least one release cycle.
- **Gaps:** agentless jobs and jobs that never start an agent are not measured.

## Disable and uninstall

- Pause everywhere instantly: define variable `NETUSAGE_DISABLE=true` at organization, project or pipeline level.
- Remove: uninstall the extension (Organization settings > Extensions).

## Validation status

- Decorator steps (Bash): automated tests on macOS, plus a run in a Linux container against a real
  `/proc/net/dev`, including hostile-input and injection tests.
- Extension manifest: packaged successfully with `tfx-cli` 0.24.2; the resulting `.vsix` requests no scopes.
  Contribution type and targets match Microsoft's pipeline decorator documentation.
- Collector: automated tests against a simulated Azure DevOps API (paging, 403 skips, resume, report).
- **Verified end to end on a live Azure DevOps Services organization (Linux, Microsoft-hosted agent):**
  decorator injection, the `netusage` attachment, daily collection through the REST API (project and build
  listing, attachment download) and the CSV report. `Agent.IsSelfHosted` reported `0` on the hosted agent.
- **Not yet exercised on a real organization:** the PowerShell steps on a Windows agent, self-hosted agents,
  and Azure DevOps Server. Steps 4 and 5 of the technical guide validate these on your pilot.
- `Agent.IsSelfHosted` is reported as `1`/`0` by agents since about v2.217; on older agents it is empty and the
  collector falls back to the agent name (`Azure Pipelines N`, `Hosted Agent`) to tell Microsoft-hosted jobs apart.
