#!/usr/bin/env python3
"""Collect NetUsage records written by the decorator and summarize them.

Read-only: issues HTTP GET requests only. Python standard library only.
The PAT is read from the ADO_PAT environment variable (never a CLI argument)
and needs only: Project and Team (Read), Build (Read).

Writes three CSVs to --out (sizes in bytes, plus GB where 1 GB = 1,000,000,000 bytes):
  daily-summary.csv    one row per UTC day for all pipelines, then one per pipeline: share this
  pipeline-totals.csv  one row per pipeline for the whole period, with a 30-day projection
  jobs.csv             one row per job (rxBytes/txBytes in bytes)
"""
import argparse
import base64
import collections
import csv
import datetime as dt
import json
import os
import re
import sys
import time
import urllib.error
import urllib.parse
import urllib.request
from concurrent.futures import ThreadPoolExecutor

ATTACHMENT_TYPE = "netusage"
MAX_JSON_BYTES = 64 * 1024
MAX_PAGE_BYTES = 32 * 1024 * 1024
STR_FIELDS = ("buildId", "project", "definition", "job", "jobId",
              "agentName", "agentOS", "agentArch", "selfHosted")
INT_FIELDS = ("startEpoch", "endEpoch", "durationSec", "rxBytes", "txBytes",
              "maxWorkersOnHost")
LOOPBACK = {"127.0.0.1", "localhost", "::1"}


class ApiError(Exception):
    def __init__(self, message, code=None):
        super().__init__(message)
        self.code = code


class _NoRedirect(urllib.request.HTTPRedirectHandler):
    """urllib would resend the Authorization header to a redirect target."""

    def redirect_request(self, *args, **kwargs):
        return None


class Api:
    def __init__(self, base_url, pat, api_version):
        parts = urllib.parse.urlsplit(base_url.rstrip("/"))
        if parts.scheme != "https" and not (
                parts.scheme == "http" and parts.hostname in LOOPBACK):
            raise ApiError("base URL must be https (http only for loopback tests)")
        if not parts.hostname:
            raise ApiError("invalid base URL")
        self.base = base_url.rstrip("/")
        self.origin = (parts.scheme, parts.netloc)
        self.api_version = api_version
        token = base64.b64encode((":" + pat).encode()).decode()
        self._auth = "Basic " + token
        self._opener = urllib.request.build_opener(_NoRedirect)

    def _same_origin(self, url):
        p = urllib.parse.urlsplit(url)
        return (p.scheme, p.netloc) == self.origin

    def get(self, url, params=None, max_bytes=MAX_PAGE_BYTES, accept="application/json"):
        if not self._same_origin(url):
            raise ApiError("refusing to send credentials to a different host")
        if params:
            url = url + ("&" if "?" in url else "?") + urllib.parse.urlencode(params)
        req = urllib.request.Request(url, method="GET", headers={
            "Authorization": self._auth, "Accept": accept})
        for attempt in range(5):
            try:
                with self._opener.open(req, timeout=30) as resp:
                    body = resp.read(max_bytes + 1)
                    if len(body) > max_bytes:
                        raise ApiError("response too large")
                    return body, resp.headers
            except urllib.error.HTTPError as e:
                if e.code in (429, 500, 502, 503, 504) and attempt < 4:
                    retry_after = e.headers.get("Retry-After", "") if e.headers else ""
                    wait = int(retry_after) if retry_after.isdigit() else 2 ** attempt
                    time.sleep(min(wait, 120))
                    continue
                if 300 <= e.code < 400:
                    raise ApiError("HTTP %d redirect; use the canonical "
                                   "organization URL" % e.code, e.code)
                raise ApiError("HTTP %d for %s" % (
                    e.code, urllib.parse.urlsplit(url).path), e.code)
            except urllib.error.URLError as e:
                if attempt < 4:
                    time.sleep(2 ** attempt)
                    continue
                raise ApiError("connection failed: %s" % e.reason)
        raise ApiError("retries exhausted")

    def get_json(self, url, params=None, max_bytes=MAX_PAGE_BYTES, accept="application/json"):
        body, headers = self.get(url, params, max_bytes, accept)
        try:
            return json.loads(body), headers
        except ValueError:
            raise ApiError("non-JSON response; check the PAT and base URL")

    def paged(self, url, params):
        params = dict(params, **{"api-version": self.api_version})
        while True:
            data, headers = self.get_json(url, params)
            for item in data.get("value", []):
                yield item
            token = headers.get("x-ms-continuationtoken")
            if not token:
                return
            params["continuationToken"] = token

    def projects(self):
        """All project names; paged with $skip until an empty page."""
        names, skip = [], 0
        while True:
            data, _ = self.get_json(self.base + "/_apis/projects", {
                "$top": 100, "$skip": skip, "api-version": self.api_version})
            page = [p["name"] for p in data.get("value", [])]
            if not page:
                return names
            names.extend(page)
            skip += len(page)


def _clean_str(value):
    return re.sub(r"[\x00-\x1f\x7f]", "", str(value))[:200]


def clean_record(raw):
    """Validate one record; keep only known fields with sane types."""
    if not isinstance(raw, dict) or raw.get("schema") != 1:
        return None
    rec = {"schema": 1}
    rec.update({k: _clean_str(raw.get(k, "")) for k in STR_FIELDS})
    for k in INT_FIELDS:
        v = raw.get(k)
        ok = isinstance(v, int) and not isinstance(v, bool) and 0 <= v < 2 ** 53
        rec[k] = v if ok else None
    return rec


def fetch_build_records(api, project, build_id):
    quoted = urllib.parse.quote(project, safe="")
    url = "%s/%s/_apis/build/builds/%s/attachments/%s" % (
        api.base, quoted, int(build_id), ATTACHMENT_TYPE)
    listing, _ = api.get_json(url, {"api-version": api.api_version})
    records = []
    for att in listing.get("value", []):
        href = (att.get("_links") or {}).get("self", {}).get("href")
        if not href:
            continue
        try:
            # attachment content is served as a file, not as an API JSON response
            raw, _ = api.get_json(href, None, MAX_JSON_BYTES, accept="*/*")
        except ApiError as e:
            if e.code != 404:
                raise  # never mark a build done with a record missing
            print("warning: build %s attachment gone: %s" % (build_id, e), file=sys.stderr)
            continue
        rec = clean_record(raw)
        if rec:
            rec["project"] = rec["project"] or project
            records.append(rec)
    return records


HOSTED_AGENT_PREFIXES = ("azure pipelines", "hosted agent", "github actions")


def is_self_hosted(rec):
    """Agent.IsSelfHosted is "1"/"0" on agents since ~v2.217; older agents don't set it."""
    flag = rec["selfHosted"].strip().lower()
    if flag in ("1", "true"):
        return True
    if flag in ("0", "false"):
        return False
    return not rec["agentName"].strip().lower().startswith(HOSTED_AGENT_PREFIXES)


def is_noisy(rec):
    """Shared self-hosted host: counters include other concurrent jobs."""
    return is_self_hosted(rec) and (rec["maxWorkersOnHost"] or 0) > 1


GB = 1000.0 ** 3  # decimal gigabyte; the *_bytes columns stay exact
ALL_PIPELINES = "ALL PIPELINES"
USAGE_COLS = ["builds", "jobs", "received_bytes", "sent_bytes", "received_gb", "sent_gb",
              "job_hours", "noisy_jobs", "jobs_missing_data"]
DAILY_COLS = ["date", "project", "pipeline"] + USAGE_COLS
TOTALS_COLS = (["project", "pipeline"] + USAGE_COLS[:6]
               + ["received_gb_per_30d", "sent_gb_per_30d"] + USAGE_COLS[6:])


def _rollup(records, key):
    groups = collections.OrderedDict()
    for r in records:
        g = groups.setdefault(key(r), {
            "builds": set(), "jobs": 0, "rx": 0, "tx": 0,
            "noisy_jobs": 0, "missing_jobs": 0, "seconds": 0})
        g["builds"].add((r["project"], r["buildId"]))
        g["jobs"] += 1
        g["seconds"] += r["durationSec"] or 0
        if r["rxBytes"] is None or r["txBytes"] is None:
            g["missing_jobs"] += 1
            continue
        g["rx"] += r["rxBytes"]
        g["tx"] += r["txBytes"]
        if is_noisy(r):
            g["noisy_jobs"] += 1
    return groups


def _usage(g):
    return {
        "builds": len(g["builds"]), "jobs": g["jobs"],
        "received_bytes": g["rx"], "sent_bytes": g["tx"],
        "received_gb": round(g["rx"] / GB, 3), "sent_gb": round(g["tx"] / GB, 3),
        "job_hours": round(g["seconds"] / 3600.0, 2),
        "noisy_jobs": g["noisy_jobs"], "jobs_missing_data": g["missing_jobs"]}


def job_date(rec):
    """UTC date the job finished (start date if the end is unknown)."""
    ts = rec["endEpoch"] or rec["startEpoch"]
    if not ts:
        return "unknown"
    return dt.datetime.fromtimestamp(ts, dt.timezone.utc).strftime("%Y-%m-%d")


def aggregate(records, window_days):
    """Per-pipeline totals for the whole period, with a 30-day projection."""
    scale = 30.0 / max(window_days, 1)
    rows = []
    for (project, definition), g in _rollup(records, lambda r: (r["project"], r["definition"])).items():
        row = {"project": project, "pipeline": definition}
        row.update(_usage(g))
        row["received_gb_per_30d"] = round(g["rx"] * scale / GB, 3)
        row["sent_gb_per_30d"] = round(g["tx"] * scale / GB, 3)
        rows.append(row)
    return rows


def aggregate_daily(records):
    """Per UTC day: one ALL PIPELINES row, then one row per pipeline."""
    per_pipeline = _rollup(records, lambda r: (job_date(r), r["project"], r["definition"]))
    per_day = _rollup(records, job_date)
    rows = []
    for day in sorted(per_day):
        row = {"date": day, "project": "ALL", "pipeline": ALL_PIPELINES}
        row.update(_usage(per_day[day]))
        rows.append(row)
        for key in sorted(k for k in per_pipeline if k[0] == day):
            row = {"date": day, "project": key[1], "pipeline": key[2]}
            row.update(_usage(per_pipeline[key]))
            rows.append(row)
    return rows


def csv_safe(value):
    """Neutralize spreadsheet formula injection from pipeline-controlled text."""
    if isinstance(value, str) and value[:1] in ("=", "+", "-", "@", "\t", "\r"):
        return "'" + value
    return value


def write_csv(path, fieldnames, rows):
    fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
    with os.fdopen(fd, "w", newline="", encoding="utf-8") as fh:
        w = csv.DictWriter(fh, fieldnames=fieldnames, extrasaction="ignore")
        w.writeheader()
        for row in rows:
            w.writerow({k: csv_safe(row.get(k)) for k in fieldnames})


def anonymize(records, out_dir):
    """Replace project/pipeline names with stable aliases; mapping stays local."""
    projects, pipelines = {}, {}
    for r in records:
        r["project"] = projects.setdefault(r["project"], "project-%03d" % (len(projects) + 1))
        r["definition"] = pipelines.setdefault(r["definition"], "pipeline-%03d" % (len(pipelines) + 1))
        r["selfHosted"] = "1" if is_self_hosted(r) else "0"  # resolve before dropping agentName
        r["job"] = ""
        r["agentName"] = ""
    path = os.path.join(out_dir, "anonymization-map.LOCAL-ONLY.json")
    fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
    with os.fdopen(fd, "w", encoding="utf-8") as fh:
        json.dump({"projects": projects, "pipelines": pipelines}, fh, indent=2)
    return path


def _private_dir(path):
    os.makedirs(path, mode=0o700, exist_ok=True)


def _private_append(path):
    fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_APPEND, 0o600)
    return os.fdopen(fd, "a", encoding="utf-8")


def _day_bounds(day):
    start = dt.datetime.strptime(day, "%Y-%m-%d").replace(tzinfo=dt.timezone.utc)
    return start, start + dt.timedelta(days=1)


def _fmt(ts):
    return ts.strftime("%Y-%m-%dT%H:%M:%SZ")


def load_done(path):
    """(project, buildId) pairs already saved for a day; tolerates a torn last line."""
    done = set()
    if os.path.exists(path):
        with open(path, encoding="utf-8") as fh:
            for line in fh:
                try:
                    row = json.loads(line)
                    done.add((row["p"], int(row["b"])))
                except (ValueError, KeyError, TypeError):
                    continue
    return done


def _scan_project(api, name, start, end, done, fh, deadline, day, chunk):
    """Save new builds of one project. Returns (complete, new_build_count)."""
    quoted = urllib.parse.quote(name, safe="")
    builds = api.paged("%s/%s/_apis/build/builds" % (api.base, quoted), {
        "minTime": _fmt(start), "maxTime": _fmt(end),
        "statusFilter": "completed", "queryOrder": "finishTimeAscending", "$top": 500})
    ids = [b["id"] for b in builds if (name, b["id"]) not in done]
    for i in range(0, len(ids), chunk):
        if deadline and time.time() > deadline:
            print("%s: time budget reached, will resume" % day, file=sys.stderr)
            return False, i
        part = ids[i:i + chunk]
        with ThreadPoolExecutor(max_workers=4) as pool:
            for bid, recs in zip(part, pool.map(
                    lambda b: fetch_build_records(api, name, b), part)):
                fh.write(json.dumps({"p": name, "b": bid, "r": recs}) + "\n")
        fh.flush()
        os.fsync(fh.fileno())
    return True, len(ids)


def scan_day(api, names, day, data_dir, deadline, chunk=100):
    """Collect one UTC day into data_dir/DAY.jsonl, resumable. True when complete.

    Projects the PAT user cannot read (HTTP 403/404) are skipped and listed in the
    completion marker; any other error aborts so the day is retried, never lost.
    """
    marker = os.path.join(data_dir, day + ".complete")
    if os.path.exists(marker):
        return True
    path = os.path.join(data_dir, day + ".jsonl")
    done = load_done(path)
    start, end = _day_bounds(day)
    skipped = []
    with _private_append(path) as fh:
        for n, name in enumerate(names, 1):
            try:
                ok, count = _scan_project(api, name, start, end, done, fh, deadline, day, chunk)
            except ApiError as e:
                if e.code in (403, 404):
                    skipped.append(name)
                    print("warning: no access to project %r, skipped" % name, file=sys.stderr)
                    continue
                raise
            if not ok:
                return False
            if count:
                print("%s %s: %d new builds saved (%d/%d projects)" % (
                    day, name, count, n, len(names)), file=sys.stderr)
    if end > dt.datetime.now(dt.timezone.utc):
        print("%s is still in progress: saved so far, not marked complete" % day, file=sys.stderr)
        return True
    with _private_append(marker) as fh:
        fh.write("complete %s\n" % _fmt(dt.datetime.now(dt.timezone.utc)))
        fh.write("projects_checked %d\n" % (len(names) - len(skipped)))
        for name in skipped:
            fh.write("skipped_no_access %s\n" % name.replace("\n", " "))
    if skipped:
        print("warning: %d project(s) not readable by this PAT user; see %s" % (
            len(skipped), marker), file=sys.stderr)
    return True


def load_days(data_dir, first_day, last_day):
    """Records from saved days in [first_day, last_day], de-duplicated."""
    records, seen, days = [], set(), 0
    for fn in sorted(os.listdir(data_dir)):
        m = re.fullmatch(r"(\d{4}-\d{2}-\d{2})\.jsonl", fn)
        if not m or not (first_day <= m.group(1) <= last_day):
            continue
        days += 1
        with open(os.path.join(data_dir, fn), encoding="utf-8") as fh:
            for line in fh:
                try:
                    row = json.loads(line)
                except ValueError:
                    continue
                for raw in row.get("r", []):
                    rec = clean_record(raw)
                    if not rec:
                        continue
                    rec["project"] = rec["project"] or str(row.get("p", ""))
                    key = (rec["project"], rec["buildId"], rec["jobId"])
                    if key not in seen:
                        seen.add(key)
                        records.append(rec)
    return records, days


def write_reports(records, window_days, out_dir, do_anonymize):
    _private_dir(out_dir)
    if do_anonymize:
        print("alias map (keep private): " + anonymize(records, out_dir))
    totals = aggregate(records, window_days)
    daily = aggregate_daily(records)
    stale = os.path.join(out_dir, "summary.csv")  # name used by earlier versions
    if os.path.exists(stale):
        os.remove(stale)
    write_csv(os.path.join(out_dir, "jobs.csv"), list(STR_FIELDS) + list(INT_FIELDS), records)
    write_csv(os.path.join(out_dir, "pipeline-totals.csv"), TOTALS_COLS, totals)
    write_csv(os.path.join(out_dir, "daily-summary.csv"), DAILY_COLS, daily)
    rx = sum(r["received_bytes"] for r in totals)
    tx = sum(r["sent_bytes"] for r in totals)
    print("jobs recorded: %d over %.0f day(s)" % (len(records), window_days))
    print("received (downloads): %.2f GB   sent (uploads): %.2f GB   (1 GB = 10^9 bytes)" % (rx / GB, tx / GB))
    print("wrote %s" % os.path.abspath(out_dir))
    print("SHARE THIS FILE: %s" % os.path.abspath(os.path.join(out_dir, "daily-summary.csv")))


def parse_args(argv):
    p = argparse.ArgumentParser(description=__doc__.split("\n")[0])
    p.add_argument("--url", help="https://dev.azure.com/ORG  or  https://server/tfs/COLLECTION")
    p.add_argument("--project", action="append",
                   help="limit to this project (repeatable); default all")
    p.add_argument("--api-version", default="7.1",
                   help="use 7.0 or 6.0 for older Azure DevOps Server")
    mode = p.add_mutually_exclusive_group()
    mode.add_argument("--daily", action="store_true",
                      help="save finished builds per UTC day into --data-dir (resumable)")
    mode.add_argument("--report", action="store_true",
                      help="build CSVs from --data-dir; no API calls, no PAT")
    p.add_argument("--data-dir", default="netusage-data")
    p.add_argument("--date", help="--daily: only this UTC day YYYY-MM-DD")
    p.add_argument("--backfill-days", type=int, default=3,
                   help="--daily: also fill missing days up to N days back (default 3)")
    p.add_argument("--time-budget-minutes", type=int, default=0,
                   help="--daily: stop cleanly after N minutes; rerun to resume (exit code 3)")
    p.add_argument("--days", type=int, default=30, help="look-back window (default 30)")
    p.add_argument("--since", help="start date YYYY-MM-DD (overrides --days)")
    p.add_argument("--out", default="netusage-out", help="CSV output directory")
    p.add_argument("--max-builds", type=int, default=20000, help="one-shot mode cap")
    p.add_argument("--anonymize", action="store_true",
                   help="alias project/pipeline names in the CSVs")
    return p.parse_args(argv)


def _window(args):
    now = dt.datetime.now(dt.timezone.utc)
    if args.since:
        start = dt.datetime.strptime(args.since, "%Y-%m-%d").replace(tzinfo=dt.timezone.utc)
    else:
        start = now - dt.timedelta(days=args.days)
    return start, now


def _make_api(args):
    pat = os.environ.get("ADO_PAT", "")
    if not pat:
        sys.exit("Set the ADO_PAT environment variable (read-only PAT).")
    if not args.url:
        sys.exit("--url is required")
    return Api(args.url, pat, args.api_version)


def _project_names(api, args):
    names = api.projects()
    return [n for n in names if n in args.project] if args.project else names


def run_report(args):
    start, now = _window(args)
    _private_dir(args.data_dir)
    records, days = load_days(args.data_dir, start.strftime("%Y-%m-%d"), now.strftime("%Y-%m-%d"))
    if not days:
        sys.exit("no saved days found in %s" % args.data_dir)
    write_reports(records, days, args.out, args.anonymize)


def run_daily(args):
    api = _make_api(args)
    _private_dir(args.data_dir)
    today = dt.datetime.now(dt.timezone.utc).date()
    if args.date:
        days = [args.date]
    else:
        days = [(today - dt.timedelta(days=n)).isoformat()
                for n in range(max(args.backfill_days, 1), 0, -1)]
    deadline = time.time() + args.time_budget_minutes * 60 if args.time_budget_minutes else None
    names = _project_names(api, args)
    finished = True
    for day in days:
        if not scan_day(api, names, day, args.data_dir, deadline):
            finished = False
            break
    sys.exit(0 if finished else 3)


def run_oneshot(args):
    api = _make_api(args)
    start, now = _window(args)
    window_days = max((now - start).total_seconds() / 86400.0, 1)
    names = _project_names(api, args)
    records, scanned = [], 0
    for name in names:
        quoted = urllib.parse.quote(name, safe="")
        try:
            builds = api.paged("%s/%s/_apis/build/builds" % (api.base, quoted), {
                "minTime": _fmt(start), "statusFilter": "completed", "queryOrder": "finishTimeAscending", "$top": 500})
            ids = []
            for b in builds:
                ids.append(b["id"])
                if scanned + len(ids) >= args.max_builds:
                    break
            scanned += len(ids)
            with ThreadPoolExecutor(max_workers=4) as pool:
                for recs in pool.map(lambda i: fetch_build_records(api, name, i), ids):
                    records.extend(recs)
        except ApiError as e:
            if e.code in (403, 404):
                print("warning: no access to project %r, skipped" % name, file=sys.stderr)
                continue
            raise
        print("%s: %d builds scanned" % (name, len(ids)), file=sys.stderr)
        if scanned >= args.max_builds:
            print("warning: --max-builds reached; use --daily for large estates", file=sys.stderr)
            break
    write_reports(records, window_days, args.out, args.anonymize)


def main(argv=None):
    args = parse_args(argv)
    try:
        if args.report:
            run_report(args)
        elif args.daily:
            run_daily(args)
        else:
            run_oneshot(args)
    except ApiError as e:
        sys.exit("error: %s" % e)


if __name__ == "__main__":
    main()
