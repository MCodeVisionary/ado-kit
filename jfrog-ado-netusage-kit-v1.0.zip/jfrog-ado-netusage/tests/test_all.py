"""Tests: decorator bash steps (Linux/macOS only) and the collector.
Run:  python3 -I -m unittest discover -s tests -v   (from the repo root)
PowerShell steps are not covered here; see README "Validation".
"""
import json
import os
import re
import subprocess
import sys
import tempfile
import threading
import unittest
from http.server import BaseHTTPRequestHandler, HTTPServer
from urllib.parse import parse_qs, urlsplit

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.join(ROOT, "collector"))
import collect_netusage as cn  # noqa: E402


def bash_script(yml_path):
    """Return the inline script of the first task (Bash@3) in a decorator file."""
    with open(yml_path, encoding="utf-8") as fh:
        lines = fh.read().splitlines()
    for i, line in enumerate(lines):
        m = re.match(r"^(\s+)script: \|\s*$", line)
        if m:
            base = len(m.group(1))
            body = []
            for l in lines[i + 1:]:
                if l.strip() and len(l) - len(l.lstrip()) <= base:
                    break
                body.append(l[base + 2:] if l.strip() else "")
            return "\n".join(body) + "\n"
    raise AssertionError("no script found in " + yml_path)


class DecoratorBashTests(unittest.TestCase):
    def run_step(self, script, env):
        full = dict(os.environ, **env)
        return subprocess.run(["bash", "-c", script], env=full, capture_output=True,
                              text=True, timeout=60)

    def test_pre_post_roundtrip_with_hostile_values(self):
        pre = bash_script(os.path.join(ROOT, "decorators", "netusage-pre.yml"))
        post = bash_script(os.path.join(ROOT, "decorators", "netusage-post.yml"))
        with tempfile.TemporaryDirectory() as tmp:
            marker = os.path.join(tmp, "PWNED")
            hostile = 'x"y\\z `touch %s` $(touch %s) ##vso[task.setvariable variable=a]b\nline2' % (marker, marker)
            env = {
                "NU_JOBID": "0123abcd-4567-89ab-cdef-0123456789ab", "NU_TMP": tmp,
                "NU_BUILDID": "42", "NU_PROJECT": hostile, "NU_DEFNAME": hostile,
                "NU_JOBNAME": "$(Agent.JobName)", "NU_AGENTNAME": "agent1",
                "NU_AGENTOS": "Darwin", "NU_ARCH": "ARM64", "NU_SELFHOSTED": "True"}
            r = self.run_step(pre, env)
            self.assertEqual(r.returncode, 0, r.stderr)
            self.assertTrue(os.path.exists(os.path.join(tmp, "netusage_%s.start" % env["NU_JOBID"])))
            r = self.run_step(post, env)
            self.assertEqual(r.returncode, 0, r.stderr)
            self.assertFalse(os.path.exists(marker), "command injection executed")
            line = [l for l in r.stdout.splitlines() if l.startswith("NETUSAGE ")]
            self.assertEqual(len(line), 1, r.stdout)
            rec = json.loads(line[0][len("NETUSAGE "):])
            self.assertEqual(rec["schema"], 1)
            self.assertEqual(rec["jobId"], env["NU_JOBID"])
            self.assertEqual(rec["job"], "")  # unexpanded macro dropped
            self.assertNotIn("\n", rec["project"])
            self.assertIn("##vso[task.setvariable", rec["project"])  # data, not at line start
            self.assertTrue(isinstance(rec["rxBytes"], int) or rec["rxBytes"] is None)
            # no log line may begin with a logging command except our attachment
            for l in r.stdout.splitlines():
                if l.startswith("##vso["):
                    self.assertTrue(l.startswith("##vso[task.addattachment type=netusage;name=0123abcd-"), l)
            self.assertFalse(os.path.exists(os.path.join(tmp, "netusage_%s.start" % env["NU_JOBID"])))

    def test_rejects_bad_jobid_and_missing_snapshot(self):
        pre = bash_script(os.path.join(ROOT, "decorators", "netusage-pre.yml"))
        post = bash_script(os.path.join(ROOT, "decorators", "netusage-post.yml"))
        with tempfile.TemporaryDirectory() as tmp:
            bad = {"NU_JOBID": "../../etc/x", "NU_TMP": tmp}
            self.assertEqual(self.run_step(pre, bad).returncode, 0)
            self.assertEqual(os.listdir(tmp), [])
            good = {"NU_JOBID": "0123abcd-4567", "NU_TMP": tmp}
            r = self.run_step(post, good)
            self.assertEqual(r.returncode, 0)
            self.assertIn("no start snapshot", r.stdout)


class CollectorUnitTests(unittest.TestCase):
    def test_clean_record(self):
        self.assertIsNone(cn.clean_record({"schema": 2}))
        rec = cn.clean_record({"schema": 1, "project": "p\x00" + "a" * 500, "rxBytes": -5,
                               "txBytes": True, "durationSec": 3, "evil": "x"})
        self.assertEqual(len(rec["project"]), 200)
        self.assertNotIn("\x00", rec["project"])
        self.assertIsNone(rec["rxBytes"])
        self.assertIsNone(rec["txBytes"])
        self.assertEqual(rec["durationSec"], 3)
        self.assertNotIn("evil", rec)

    def test_csv_safe(self):
        for s in ("=1+1", "+x", "-x", "@SUM(A1)"):
            self.assertTrue(cn.csv_safe(s).startswith("'"))
        self.assertEqual(cn.csv_safe("ok"), "ok")
        self.assertEqual(cn.csv_safe(5), 5)

    def test_aggregate_and_noise(self):
        base = dict(project="P", definition="D", job="j", jobId="1", agentName="a",
                    agentOS="Linux", agentArch="X64", selfHosted="True",
                    startEpoch=1, endEpoch=2, durationSec=3600, maxWorkersOnHost=1)
        recs = [dict(base, buildId="1", rxBytes=2 * 10 ** 9, txBytes=10 ** 9),
                dict(base, buildId="2", rxBytes=10 ** 9, txBytes=0, maxWorkersOnHost=3),
                dict(base, buildId="2", rxBytes=None, txBytes=None)]
        rows = cn.aggregate(recs, window_days=15)
        self.assertEqual(len(rows), 1)
        r = rows[0]
        self.assertEqual((r["builds"], r["jobs"], r["noisy_jobs"], r["jobs_missing_data"]), (2, 3, 1, 1))
        self.assertEqual(r["received_bytes"], 3 * 10 ** 9)
        self.assertEqual(r["received_gb"], 3.0)  # decimal GB
        self.assertEqual(r["received_gb_per_30d"], 6.0)

    def test_daily_summary(self):
        day1, day2 = 1792800000, 1792800000 + 86400  # 2026-10-24 and 2026-10-25 UTC
        base = dict(job="j", jobId="1", agentName="a", agentOS="Linux", agentArch="X64",
                    selfHosted="0", startEpoch=None, durationSec=60, maxWorkersOnHost=1, txBytes=0)
        recs = [dict(base, project="P", definition="A", buildId="1", endEpoch=day1, rxBytes=100),
                dict(base, project="P", definition="B", buildId="2", endEpoch=day1, rxBytes=50),
                dict(base, project="Q", definition="A", buildId="1", endEpoch=day2, rxBytes=7),
                dict(base, project="P", definition="A", buildId="3", endEpoch=None, rxBytes=1)]
        rows = cn.aggregate_daily(recs)
        got = [(r["date"], r["project"], r["pipeline"], r["builds"], r["received_bytes"]) for r in rows]
        self.assertEqual(got, [
            ("2026-10-24", "ALL", "ALL PIPELINES", 2, 150),
            ("2026-10-24", "P", "A", 1, 100),
            ("2026-10-24", "P", "B", 1, 50),
            ("2026-10-25", "ALL", "ALL PIPELINES", 1, 7),  # same build id, other project: distinct
            ("2026-10-25", "Q", "A", 1, 7),
            ("unknown", "ALL", "ALL PIPELINES", 1, 1),
            ("unknown", "P", "A", 1, 1)])

    def test_self_hosted_detection(self):
        rec = lambda flag, name: {"selfHosted": flag, "agentName": name}
        self.assertTrue(cn.is_self_hosted(rec("1", "Azure Pipelines 3")))
        self.assertFalse(cn.is_self_hosted(rec("0", "build-01")))
        self.assertFalse(cn.is_self_hosted(rec("", "Azure Pipelines 3")))
        self.assertTrue(cn.is_self_hosted(rec("", "build-01")))

    def test_api_origin_rules(self):
        with self.assertRaises(cn.ApiError):
            cn.Api("http://dev.azure.com/org", "x", "7.1")
        api = cn.Api("https://dev.azure.com/org", "x", "7.1")
        with self.assertRaises(cn.ApiError):
            api.get("https://evil.example.com/steal")


class _Handler(BaseHTTPRequestHandler):
    port = 0
    seen_auth = []
    paths = []

    def log_message(self, *a):
        pass

    def _send(self, obj, headers=None):
        body = json.dumps(obj).encode()
        self.send_response(200)
        self.send_header("Content-Type", "application/json")
        for k, v in (headers or {}).items():
            self.send_header(k, v)
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self):
        _Handler.seen_auth.append(self.headers.get("Authorization"))
        path = self.path.split("?")[0]
        _Handler.paths.append(path)
        if path == "/_apis/projects":
            # one project per page, to exercise $skip paging
            skip = int(parse_qs(urlsplit(self.path).query).get("$skip", ["0"])[0])
            page = [{"name": "My Proj"}, {"name": "Secret"}][skip:skip + 1]
            self._send({"value": page})
        elif path == "/Secret/_apis/build/builds":
            self.send_response(403)
            self.end_headers()
        elif path == "/My%20Proj/_apis/build/builds":
            self._send({"value": [{"id": 7}]})
        elif path == "/My%20Proj/_apis/build/builds/7/attachments/netusage":
            href = "http://127.0.0.1:%d/att/1" % _Handler.port
            self._send({"count": 1, "value": [{"name": "j", "_links": {"self": {"href": href}}}]})
        elif path == "/att/1":
            self._send({"schema": 1, "buildId": "7", "project": "My Proj", "definition": "=cmd",
                        "job": "build", "jobId": "j1", "agentName": "a", "agentOS": "Linux",
                        "agentArch": "X64", "selfHosted": "False", "startEpoch": 1,
                        "endEpoch": 61, "durationSec": 60, "rxBytes": 1073741824,
                        "txBytes": 536870912, "maxWorkersOnHost": 1})
        else:
            self.send_response(404)
            self.end_headers()


class CollectorEndToEndTest(unittest.TestCase):
    def test_end_to_end_against_mock(self):
        srv = HTTPServer(("127.0.0.1", 0), _Handler)
        _Handler.port = srv.server_port
        threading.Thread(target=srv.serve_forever, daemon=True).start()
        try:
            with tempfile.TemporaryDirectory() as out:
                os.environ["ADO_PAT"] = "dummy-pat"
                cn.main(["--url", "http://127.0.0.1:%d" % srv.server_port, "--out", out, "--days", "30"])
                with open(os.path.join(out, "pipeline-totals.csv"), encoding="utf-8") as fh:
                    totals = fh.read()
                self.assertIn("'=cmd", totals)  # formula neutralized
                self.assertIn(",1073741824,536870912,1.074,0.537,", totals)
                with open(os.path.join(out, "daily-summary.csv"), encoding="utf-8") as fh:
                    daily = fh.read().splitlines()
                self.assertEqual(daily[0].split(",")[:3], ["date", "project", "pipeline"])
                self.assertTrue(daily[1].startswith("1970-01-01,ALL,ALL PIPELINES,1,1,1073741824,"))
                self.assertTrue(daily[2].startswith("1970-01-01,My Proj,'=cmd,1,1,"))
                self.assertFalse(os.path.exists(os.path.join(out, "summary.csv")))
                self.assertEqual(oct(os.stat(os.path.join(out, "jobs.csv")).st_mode & 0o777), "0o600")
                self.assertTrue(all(a and a.startswith("Basic ") for a in _Handler.seen_auth))
        finally:
            srv.shutdown()
            srv.server_close()


class CollectorDailyTest(unittest.TestCase):
    def _serve(self):
        srv = HTTPServer(("127.0.0.1", 0), _Handler)
        _Handler.port = srv.server_port
        _Handler.paths.clear()
        threading.Thread(target=srv.serve_forever, daemon=True).start()
        return srv

    def test_today_is_never_marked_complete(self):
        srv = self._serve()
        url = "http://127.0.0.1:%d" % srv.server_port
        os.environ["ADO_PAT"] = "dummy-pat"
        try:
            with tempfile.TemporaryDirectory() as tmp:
                day = cn.dt.datetime.now(cn.dt.timezone.utc).strftime("%Y-%m-%d")
                with self.assertRaises(SystemExit) as ex:
                    cn.main(["--daily", "--url", url, "--data-dir", tmp, "--date", day])
                self.assertEqual(ex.exception.code, 0)
                self.assertTrue(os.path.exists(os.path.join(tmp, day + ".jsonl")))
                self.assertFalse(os.path.exists(os.path.join(tmp, day + ".complete")))
        finally:
            srv.shutdown()
            srv.server_close()

    def test_daily_resume_and_report(self):
        srv = self._serve()
        url = "http://127.0.0.1:%d" % srv.server_port
        os.environ["ADO_PAT"] = "dummy-pat"
        try:
            with tempfile.TemporaryDirectory() as tmp:
                data, out = os.path.join(tmp, "data"), os.path.join(tmp, "out")
                with self.assertRaises(SystemExit) as ex:
                    cn.main(["--daily", "--url", url, "--data-dir", data, "--date", "2026-10-19"])
                self.assertEqual(ex.exception.code, 0)
                marker = os.path.join(data, "2026-10-19.complete")
                self.assertTrue(os.path.exists(marker))
                with open(marker, encoding="utf-8") as fh:
                    self.assertIn("skipped_no_access Secret", fh.read())
                with open(os.path.join(data, "2026-10-19.jsonl"), encoding="utf-8") as fh:
                    self.assertEqual(len(fh.readlines()), 1)
                # complete day is skipped: no further attachment calls
                _Handler.paths.clear()
                with self.assertRaises(SystemExit):
                    cn.main(["--daily", "--url", url, "--data-dir", data, "--date", "2026-10-19"])
                self.assertFalse(any("attachments" in x for x in _Handler.paths))
                # interrupted day: saved build is not refetched, torn last line tolerated
                os.remove(os.path.join(data, "2026-10-19.complete"))
                with open(os.path.join(data, "2026-10-19.jsonl"), "a", encoding="utf-8") as fh:
                    fh.write('{"p": "My Pro')
                _Handler.paths.clear()
                with self.assertRaises(SystemExit):
                    cn.main(["--daily", "--url", url, "--data-dir", data, "--date", "2026-10-19"])
                self.assertFalse(any("attachments" in x for x in _Handler.paths))
                # report works offline from saved files and de-duplicates
                cn.main(["--report", "--data-dir", data, "--out", out, "--since", "2026-10-19"])
                with open(os.path.join(out, "jobs.csv"), encoding="utf-8") as fh:
                    self.assertEqual(len(fh.readlines()), 2)  # header + 1 job
        finally:
            srv.shutdown()
            srv.server_close()


if __name__ == "__main__":
    unittest.main()
