#!/usr/bin/env bash
# One-step runner: prompts for the PAT (hidden, never saved), runs the daily collector
# for one UTC day, builds the CSVs, then forgets the token. Works from any folder.
# Usage: run-collector.sh ORG_URL [YYYY-MM-DD]     (date defaults to yesterday, UTC)
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
URL="${1:?usage: run-collector.sh https://dev.azure.com/ORG [YYYY-MM-DD]}"
DAY="${2:-$(date -u -v-1d +%F 2>/dev/null || date -u -d yesterday +%F)}"

if [ -z "${ADO_PAT:-}" ]; then
  [ -t 0 ] || { echo "Run this in a terminal so the PAT prompt can read your input." >&2; exit 1; }
  read -rs -p "Paste PAT (hidden): " ADO_PAT; echo
  export ADO_PAT
fi
trap 'unset ADO_PAT' EXIT

cd "$ROOT"
python3 -I collector/collect_netusage.py --daily --url "$URL" --data-dir netusage-data --date "$DAY"
python3 -I collector/collect_netusage.py --report --data-dir netusage-data --out netusage-out --since "$DAY"
echo "Done. File to share: $ROOT/netusage-out/daily-summary.csv. Revoke the PAT when finished."
