#!/usr/bin/env bash
# Build the private .vsix and checksums. Run from the repo root.
# tfx-cli is the only external tool; install it from your approved internal npm
# registry (e.g. an Artifactory npm remote), not directly from the public registry.
set -euo pipefail
cd "$(dirname "$0")/.."

command -v tfx >/dev/null || { echo "tfx-cli not found (npm i -g tfx-cli via your internal registry)"; exit 1; }
grep -q 'REPLACE-WITH' vss-extension.json && { echo "Set your publisher id in vss-extension.json first"; exit 1; }

python3 -I -m unittest discover -s tests
tfx extension create --manifest-globs vss-extension.json --output-path dist --no-prompt
( cd dist && shasum -a 256 ./*.vsix > ../SHA256SUMS.vsix )
echo "Built dist/*.vsix; checksum in SHA256SUMS.vsix"
